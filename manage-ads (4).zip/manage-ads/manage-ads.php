<?php

/**
 *
 * @link              https://https://dazzlebirds.com/
 * @since             1.0.0
 * @package           Manage_Ads
 *
 * @wordpress-plugin
 * Plugin Name:       Manage Ads
 * Plugin URI:        https://https://dazzlebirds.com/
 * Description:       Manage and optimize your ads in WordPress
 * Version:           1.0.0
 * Author:            Hardik Mehta
 * Author URI:        https://https://dazzlebirds.com//
 * Text Domain:       manage-ads
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'MANAGE_ADS_VERSION', '1.0.0' );
define('MANAGE_ADS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MNG_DIR_URl', plugin_dir_url(__FILE__));
define('MANAGE_ADS_SITE_URL', 'https://dazzlebirds.com/');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-manage-ads-activator.php
 */
function activate_manage_ads() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-manage-ads-activator.php';
	Manage_Ads_Activator::activate();
}



/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-manage-ads-deactivator.php
 */
function deactivate_manage_ads() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-manage-ads-deactivator.php';
	Manage_Ads_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_manage_ads' );
register_deactivation_hook( __FILE__, 'deactivate_manage_ads' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-manage-ads.php';

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes\admin\manage-ads-header.php'; 

/**
 * Begins execution of the plugin.
 *
 *
 * @since    1.0.0
 */
function run_manage_ads() {

	$plugin = new Manage_Ads();
	$plugin->run();

}
run_manage_ads();


