<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://dazzlebirds.com/
 * @since      1.0.0
 *
 * @package    Manage_Ads
 * @subpackage Manage_Ads/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Manage_Ads
 * @subpackage Manage_Ads/includes
 * @author     Hardik Mehta <methahardik24@gmail.com>
 */
class Manage_Ads_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
