<!-- manage-ads-header.php -->
<div id="manage-ads-header">
    <div id="manage-ads-header-wrapper">
        <div class="heading_sec">       
            <img src="<?php echo MNG_DIR_URl .'admin\images\manage-ads-logo.jpg'; ?>" width="50px" height="50px" alt="Manage Ads Logo">
            <h1><?php echo esc_html($title); ?></h1>
        </div>
        <div id="manage-ads-header-actions">
            <?php if ('' !== $new_button_label) : ?>
                <a href="<?php echo esc_url($new_button_href); ?>" class="header-action button manage-ads-button-primary">
                    <span class="dashicons dashicons-plus"></span><?php echo esc_html($new_button_label); ?>
                </a>
            <?php endif; ?>
            <?php if ('' !== $tooltip) : ?>
                <span class="manage-ads-help"><span class="manage-ads-tooltip"><?php echo esc_html($tooltip); ?></span></span>
            <?php endif; ?>
        </div>
        <div id="manage-ads-header-links">
            <?php if ('' !== $reset_href) : ?>
                <a href="<?php echo esc_url($reset_href); ?>" class="button manage-ads-button-secondary manage-ads-button-icon-right">
                    <?php esc_html_e('Reset', 'manage-ads'); ?><span class="dashicons dashicons-undo"></span>
                </a>
            <?php endif; ?>
            <?php if ($show_filter_button) : ?>
                <a id="manage-ads-show-filters" class="button manage-ads-button-secondary manage-ads-button-icon-right <?php echo esc_attr($filter_disabled); ?>">
                    <?php esc_html_e('Filters', 'manage-ads'); ?><span class="dashicons dashicons-filter"></span>
                </a>
            <?php endif; ?>
            <?php if ($show_screen_options) : ?>
                <a id="manage-ads-show-screen-options" class="button manage-ads-button-secondary"><?php esc_html_e('Screen Options', 'manage-ads'); ?></a>
            <?php endif; ?>
            <a href="<?php echo esc_url($MANAGE_ADS_SITE_URL); ?>" target="_blank" class="button manage-ads-button-secondary manage-ads-button-icon-right">
                <?php esc_html_e('Manual', 'manage-ads'); ?><span class="dashicons dashicons-welcome-learn-more"></span>
            </a>
        </div>
    </div>
</div>
