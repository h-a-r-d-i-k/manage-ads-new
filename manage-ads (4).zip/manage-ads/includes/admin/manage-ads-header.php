<?php
/**
 * The class is responsible for rendering a branded header on plugin pages in the WordPress admin area.
 *
 * @package ManageAds
 * @since   1.0.0
 */

class Manage_Ads_Header {

    /**
     * Hook into WordPress.
     *
     * @return void
     */
    public function hooks(): void {
        add_action('in_admin_header', [$this, 'render']);
    }

    /**
     * Add a branded header to plugin pages
     */
    public function render() {

        // Early bail!!
        if (!$this->is_manage_ads_screen()) {
            return;
        }

        $screen = get_current_screen();
        $MANAGE_ADS_SITE_URL = MANAGE_ADS_SITE_URL;
        $new_button_label = '';
        $new_button_href = '';
        $show_filter_button = false;
        $reset_href = '';
        $filter_disabled = '';
        $show_screen_options = false;
        $title = get_admin_page_title();
        $tooltip = '';

        switch ($screen->id) {
            case 'toplevel_page_manage-ads':
                $title = __('Dashboard', 'manage-ads');
                break;
            case 'manage_ads':
                $title = __('Add New Ad', 'manage-ads');
                $new_button_label = __('New Ad', 'manage-ads');
                $new_button_href     = admin_url( 'post-new.php?post_type=manage_ads' );
                break;
            case 'edit-manage_ads':
                $title = __('Your Ads', 'manage-ads');
                $new_button_label = __('New Ad', 'manage-ads');
                $new_button_href     = admin_url( 'post-new.php?post_type=manage_ads' );
                break;
            case 'manage-ads_page_manage-ads-groups':
                $title = __('Ad Groups', 'manage-ads');
                $new_button_label = __('New Group', 'manage-ads');
                $new_button_href = admin_url( 'admin.php?page=manage-ads-groups&group=new' );
              //  $tooltip = $this->get_group_tooltip_description();
                break;
            case 'manage-ads_page_manage-ads-placements':
                $title = __('Ad Placements', 'manage-ads');
                $new_button_label = __('New Placement', 'manage-ads');
                $new_button_href = admin_url( 'admin.php?page=manage-ads-placements&placement=new' );
               // $tooltip = $this->get_placement_tooltip_description();
                break;
            case 'manage-ads_page_manage-ads-settings':
                $title = __('Settings', 'manage-ads');
                break;
        }

        include plugin_dir_path(__FILE__) . 'render/header.php';
    }

    /**
     * Helper function to check if current screen is related to Manage Ads plugin.
     */
    public function is_manage_ads_screen() {
        $screen = get_current_screen(); 
       // var_dump($screen);
        $manage_ads_screens = [
            'toplevel_page_manage-ads',
            'manage_ads',
            'edit-manage_ads_group',
            'edit-manage_ads',
            'manage-ads_page_manage-ads-groups',
            'manage-ads_page_manage-ads-placements',
            'manage-ads_page_manage-ads-settings',
        ];
        return in_array($screen->id, $manage_ads_screens);
    }

    /**
     * Placement 'tooltip' description
     *
     * @return string
     */
    public static function get_placement_tooltip_description(): string {
        return __( 'Placements are customizable ad spots on your site. Use them to see and change all the assigned ads and groups on this page. Furthermore, you can set up exclusive features like Cache Busting, Lazy Loading, AdBlocker fallbacks, or Parallax effects.', 'manage-ads' );
    }

    /**
     * Group 'tooltip' description
     *
     * @return string
     */
    public static function get_group_tooltip_description(): string {
        return __( 'Ad Groups are a flexible method to bundle ads. Use them to create ad rotations, run split tests, and organize your ads in the backend. An ad can belong to multiple ad groups.', 'manage-ads' );
    }
    
}
?>
