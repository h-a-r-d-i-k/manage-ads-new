<?php
$action = isset($_GET['placement']) ? $_GET['placement'] : '';
$term_id = isset($_GET['term_id']) ? intval($_GET['term_id']) : 0;

if (($action === 'new') || ($action === 'edit' && $term_id)) {
    render_ad_placement_term_form($term_id);
} else {
    render_manage_ads_placement_page();
}

function render_manage_ads_placement_page() {
    $terms = get_terms([
        'taxonomy' => 'manage_ads_placement',
        'hide_empty' => false,
    ]);
    ?>
    <div class="manage-ads-section-placement"> 
        <form id="manage-ads-placements-form" method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('bulk_action_nonce', '_wpnonce_bulk_action'); ?>
            <input type="hidden" name="action" value="bulk_delete_manage_ads_placement">

            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <label for="bulk-action-selector-top" class="screen-reader-text"><?php _e('Select bulk action', 'manage-ads'); ?></label>
                    <select name="bulk-action" id="bulk-action-selector-top">
                        <option value="-1"><?php _e('Bulk Actions', 'manage-ads'); ?></option>
                        <option value="delete"><?php _e('Delete', 'manage-ads'); ?></option>
                    </select>
                    <input type="submit" id="doaction" class="button action" value="<?php _e('Apply', 'manage-ads'); ?>">
                </div>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column">
                            <input id="cb-select-all-1" type="checkbox">
                        </td>                       
                        <th scope="col" id="name" class="manage-column column-name column-primary"><?php _e('Name', 'manage-ads'); ?></th>  
                        <th scope="col" id="manage-ads-placement-type" class="manage-column column-type"><?php _e('Type', 'manage-ads'); ?></th> 
                        <th scope="col" id="manage-ads-placement-details" class="manage-column column-details"><?php _e('Details', 'manage-ads'); ?></th>                     
                        <th scope="col" id="count" class="manage-column column-count"><?php _e('Ads', 'manage-ads'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($terms) && !is_wp_error($terms)): ?>
                        <?php foreach ($terms as $term):
                            $manage_placement_type = get_term_meta($term->term_id, 'manage_placement_type', true);
                            ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="bulk-delete[]" value="<?php echo esc_attr($term->term_id); ?>">
                                </th>
                                
                                <td class="column-primary">
                                    <strong>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=manage-ads-placements&placement=edit&term_id=' . $term->term_id)); ?>">
                                            <?php echo esc_html($term->name); ?>
                                        </a>
                                    </strong>
                                    <div class="row-actions">
                                        <span class="edit">
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=manage-ads-placements&placement=edit&term_id=' . $term->term_id)); ?>">
                                                <?php _e('Edit', 'manage-ads'); ?>
                                            </a>
                                        </span>
                                        |
                                        <span class="delete">
                                            <a href="<?php echo esc_url(wp_nonce_url(admin_url('edit-tags.php?action=delete&taxonomy=manage_ads_placement&tag_ID=' . $term->term_id . '&post_type=manage_ads'), 'delete-tag_' . $term->term_id)); ?>">
                                                <?php _e('Delete', 'manage-ads'); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td class="manage-ad-types placement">
                                    <img src="<?php echo MNG_DIR_URl . 'admin/images/'. $manage_placement_type .'.svg'; ?>" alt="<?php echo esc_attr($manage_placement_type); ?>" style="width: 50px;">
                                    <div class="manage-ads-group-type-tooltip">
                                        <strong><?php echo esc_attr($manage_placement_type); ?></strong>
                                    </div>
                                </td>
                                <td class="manage-ad-details">
                                   
                                    <div class="manage-ads-placement-type-details">
                                      <p> 
                                        <span><?php _e('Type: ', 'manage-ads'); ?></span>
                                        <span><?php echo esc_attr($manage_placement_type); ?></span>
                                      </p>
                                      <p> 
                                        <span><?php _e('ID: ', 'manage-ads'); ?></span>
                                        <span><?php echo esc_attr($term->term_id); ?></span>
                                      </p>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                    // Term meta se selected posts ko retrieve karna
                                    $selected_posts = get_term_meta($term->term_id, 'selected_manage_ads_posts', true);

                                    // Ensure karna ki $selected_posts ek array hai
                                    if (!is_array($selected_posts)) {
                                        $selected_posts = array();
                                    }

                                    if (!empty($selected_posts)) {
                                        ?>
                                        <div>
                                        <?php 
                                        foreach ($selected_posts as $post_id) {
                                            $post_title = get_the_title($post_id);
                                            $edit_link = get_edit_post_link($post_id);
                                            ?>
                                            <a href="<?php echo esc_url($edit_link); ?>"><?php echo esc_html($post_title); ?></a><br>
                                            <?php 
                                        } 
                                        ?>
                                        </div>
                                        <?php
                                    } else {
                                        echo 'No posts selected.';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4"><?php _e('No ad and placement placement found.', 'manage-ads'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
    <?php
}


function render_ad_placement_term_form($term_id = 0) {
    $is_editing = ($term_id != 0);
    $term = $is_editing ? get_term($term_id, 'manage_ads_placement') : null;
    $manage_placement_type = $is_editing ? get_term_meta($term_id, 'manage_placement_type', true) : '';
    $manage_placement_visible_ads_count = $is_editing ? get_term_meta($term_id, 'manage_placement_visible_ads_count', true) : '1';

    $title = $is_editing ? __('Edit Placement', 'manage-ads') : __('Add New Placement', 'manage-ads');
    $button_text = $is_editing ? __('Update Placement', 'manage-ads') : __('Add Placement', 'manage-ads');

    // Get selected manage_ads_posts (if editing)
    $selected_posts = $is_editing ? get_term_meta($term_id, 'selected_placement', true) : '';
    $selected_post_id = isset($selected_posts) ? $selected_posts : '';

    ?>
    <div class="manage-ads-section">
        <h1><?php echo esc_html($title); ?></h1>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="manage_ads_form">
            <?php wp_nonce_field('save_ad_placement', 'ad_placement_nonce'); ?>
            <input type="hidden" name="action" value="save_ad_placement">
            <input type="hidden" name="term_id" value="<?php echo esc_attr($term_id); ?>">

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="name"><?php _e('Name', 'manage-ads'); ?></label>
                    </th>
                    <td>
                    <input type="text" name="name" id="name" value="<?php echo isset($term) && isset($term->name) ? esc_attr($term->name) : ''; ?>" class="regular-text">
                    <p class="manage_ads_error"><?php _e('* Please enter a name.', 'manage-ads'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php _e('Type', 'manage-ads'); ?></label>
                    </th>
                    <td>
                        <div class="manage-form-types manage-buttonset placement">
                            <div class="manage-form-type">
                                <input type="radio" id="manage-form-type-default" name="manage-placement-type" value="manual" class="manage-accessible" <?php checked($manage_placement_type, 'manual'); ?>>
                                <label for="manage-form-type-default" class="manage-button manage-ui-state-active">
                                    <span class="manage-button-text">
                                        <img src="<?php echo MNG_DIR_URl . 'admin/images/manual.svg'; ?>" alt="Manual Ads" style="width: 50px;">
                                    </span>
                                </label>
                                <div class="manage-form-description">
                                    <h4><?php _e('Manual Placement', 'manage-ads'); ?></h4>
                                    <?php _e('Manual placement to use as function or shortcode.', 'manage-ads'); ?>
                                </div>
                            </div>
                            <div class="manage-form-type">
                                <input type="radio" id="manage-form-type-header-code" name="manage-placement-type" value="header-code" class="manage-accessible" <?php checked($manage_placement_type, 'header-code'); ?>>
                                <label for="manage-form-type-header-code" class="manage-button">
                                    <span class="manage-button-text">
                                        <img src="<?php echo MNG_DIR_URl . 'admin/images/header-code.svg'; ?>" alt="header-code Ads" style="width: 50px;">
                                    </span>
                                </label>
                                <div class="manage-form-description">
                                    <h4><?php _e('Header Code', 'manage-ads'); ?></h4>
                                    <?php _e('Injected in header (before closing </body> Tag).', 'manage-ads'); ?>
                                </div>
                            </div>
                            <div class="manage-form-type">
                                <input type="radio" id="manage-form-type-footer-code" name="manage-placement-type" value="footer-code" class="manage-accessible" <?php checked($manage_placement_type, 'footer-code'); ?>>
                                <label for="manage-form-type-footer-code" class="manage-button">
                                    <span class="manage-button-text">
                                        <img src="<?php echo MNG_DIR_URl . 'admin/images/footer-code.svg'; ?>" alt="footer-code Ads" style="width: 50px;">
                                    </span>
                                </label>
                                <div class="manage-form-description">
                                    <h4><?php _e('Footer Code', 'manage-ads'); ?></h4>
                                    <?php _e('Injected in Footer (before closing </body> Tag).', 'manage-ads'); ?>
                                </div>
                            </div>                            
                        </div> 
                        <p class="manage_ads_error"><?php _e('* Please select a type.', 'manage-ads'); ?></p>                      
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="manage_ads_posts"><?php _e('Select Manage Ads Posts', 'manage-ads'); ?></label>
                    </th>
                    <td>
                        <select name="selected_placement" id="manage_ads_posts">
                            <option value=""><?php _e('--not selected--', 'manage-ads'); ?></option>
                            
                            <?php
                            // Fetch Ad Groups taxonomy terms
                            $ad_groups = get_terms(array(
                                'taxonomy' => 'manage_ads_group',
                                'hide_empty' => false,
                            ));
                            if (!empty($ad_groups) && !is_wp_error($ad_groups)) {
                                echo '<optgroup label="Ad Groups">';
                                foreach ($ad_groups as $group) {
                                    ?>
                                    <option value="group_<?php echo esc_attr($group->term_id); ?>" <?php selected($selected_post_id, 'group_' . $group->term_id); ?>>
                                        <?php echo esc_html($group->name); ?>
                                    </option>
                                    <?php
                                }
                                echo '</optgroup>';
                            }

                            // Fetch 'manage_ads' posts
                            $posts = get_posts(array(
                                'post_type' => 'manage_ads',
                                'posts_per_page' => -1,
                            ));
                            if ($posts) {
                                echo '<optgroup label="Ads">';
                                foreach ($posts as $post) : setup_postdata($post);
                                    ?>
                                    <option value="ad_<?php echo esc_attr($post->ID); ?>" <?php selected($selected_post_id, 'ad_' .$post->ID); ?>>
                                        <?php echo esc_html($post->post_title); ?>
                                    </option>
                                    <?php
                                endforeach;
                                echo '</optgroup>';
                                wp_reset_postdata();
                            }
                            ?>
                        </select>
                    </td>
                </tr>                
            </table>

            <?php submit_button($button_text); ?>
        </form>
    </div>
    <?php
}


?>

