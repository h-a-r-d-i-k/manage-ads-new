<?php
class Manage_Ads_Content {
    public function get_parameters() {
        // Get content for the editor if needed
        $content = get_option('my_custom_option', '');

        ob_start();
        ?>
        <div class="inside">
            <ul id="ad-parameters-box-notices" class="advads-metabox-notices">
                <!-- Notices here -->
            </ul>

            <!-- TinyMCE Editor -->
            <div id="advanced-ads-tinymce-wrapper">
                <?php
                wp_editor($content, 'advanced-ads-tinymce', array(
                    'textarea_name' => 'manage_ad[content]',
                    'textarea_rows' => 10,
                    'teeny'         => false, // Use the full editor
                    'media_buttons' => true  // Show the media button
                ));
                ?>
            </div>

            <!-- Additional Inputs -->
            <div id="advanced-ads-ad-parameters" class="advads-option-list">
                <br class="clear">
                <span class="label">size</span>
                <div id="advanced-ads-ad-parameters-size">
                    <label>width<input type="number" value="0" name="manage_ad[width]">px</label>
                    <label>height<input type="number" value="0" name="manage_ad[height]">px</label>
                    <label><input type="checkbox" id="advads-wrapper-add-sizes" name="manage_ad[reserve_space]" value="true" >reserve this space</label>
                </div>
                <hr>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
