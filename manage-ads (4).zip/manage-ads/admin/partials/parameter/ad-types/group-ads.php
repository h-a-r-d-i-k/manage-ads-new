<?php

class Manage_Ads_Group {

    public function get_parameters($post_id) {
        // Get the saved array from the post meta
        $saved_manage_ad = get_post_meta($post_id, '_manage_add_group', true);  // Assuming you saved the array with this key

        // Extract the group_id, width, height, and checkbox values from the array, if they exist
        $saved_group_id = isset($saved_manage_ad['group']['group_id']) ? $saved_manage_ad['group']['group_id'] : '';
        $saved_width = isset($saved_manage_ad['group']['width']) ? intval($saved_manage_ad['group']['width']) : 0;
        $saved_height = isset($saved_manage_ad['group']['height']) ? intval($saved_manage_ad['group']['height']) : 0;
        $saved_reverse_space = isset($saved_manage_ad['group']['reverse_space']) && $saved_manage_ad['group']['reverse_space'] === 'true' ? 'checked' : '';

        // Get the terms for the taxonomy 'manage_ads_group'
        $terms = get_terms(array(
            'taxonomy' => 'manage_ads_group',
            'hide_empty' => false, 
        ));

        // Initialize an empty options string
        $options = '';

        // Loop through each term and create an option element
        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                // Check if this term is the selected one
                $selected = ($saved_group_id == $term->term_id) ? 'selected' : '';
                $options .= sprintf('<option value="%d" %s>%s</option>', $term->term_id, $selected, esc_html($term->name));
            }
        } else {
            $options .= '<option value="0">' . __('No groups available', 'manage-ads') . '</option>';
        }

        // Return the dynamic HTML with populated values
        return sprintf('
            <div id="manage-ads-ad-parameters" class="MNG-option-list">
                <label for="MNG-group-id" class="label">%1$s</label>
                <div>
                    <select name="manage_ad[group][group_id]" id="MNG-group-id">
                        %2$s
                    </select>
                </div>
                <hr>
                <span class="label">%3$s</span>
                <div id="manage-ads-ad-parameters-size">
                    <label>%4$s<input type="number" value="%5$d" name="manage_ad[group][width]">px</label>
                    <label>%6$s<input type="number" value="%7$d" name="manage_ad[group][height]">px</label>
                    <label><input type="checkbox" id="MNG-wrapper-add-sizes" name="manage_ad[group][reverse_space]" value="true" %8$s>%9$s</label>
                </div>
                <hr>
            </div>',
            esc_html__('Ad Group', 'manage-ads'),  // %1$s: Label for the group dropdown
            $options,  // %2$s: Dynamic options with selected
            esc_html__('Size', 'manage-ads'),  // %3$s: Label for the size section
            esc_html__('Width', 'manage-ads'),  // %4$s: Label for the width input
            $saved_width,  // %5$d: Saved width value
            esc_html__('Height', 'manage-ads'),  // %6$s: Label for the height input
            $saved_height,  // %7$d: Saved height value
            $saved_reverse_space,  // %8$s: Checkbox checked status
            esc_html__('Reserve this space', 'manage-ads')  // %9$s: Label for the reserve space checkbox
        );
    }
}

// Instantiate the class
new Manage_Ads_Group();

