<?php

class update_ads_type_parameter {
       
    /**
     * 
     * save and update add type parameter
     * @param int .
     */
    public function __construct() {
        add_action('save_post_manage_ads', [$this, 'update_and_save_manage_add_parameter']);
    }

    public function update_and_save_manage_add_parameter($post_id) {
     
        // Check if it's an autosave routine.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
    
        // Check if the post type is 'manage_ads'.
        if (get_post_type($post_id) !== 'manage_ads') {
            return;
        }

//         echo "<pre>";
//                print_r($_POST);
//         echo "<pre>";
// die;
        // Ensure that 'manage_ad' data exists in $_POST and is an array.
        if (isset($_POST['manage_ad']) && is_array($_POST['manage_ad'])) {
            $manage_ad = $_POST['manage_ad'];
    
            // Sanitize and set the ad type.
            $type = isset($manage_ad['type']) ? sanitize_text_field($manage_ad['type']) : '';
          
            // If the ad type is 'dummy', proceed to set the URL, width, and height.
            if(!empty($type)){

                update_post_meta($post_id, '_manage_add_type', $type);

                $data = array();

                if ($type === 'dummy') {

                    $data['dummy']['url'] = isset($manage_ad['dummy']['url']) ? sanitize_text_field($manage_ad['dummy']['url']) : '';
                    $data['dummy']['width'] = isset($manage_ad['dummy']['width']) ? sanitize_text_field($manage_ad['dummy']['width']) : '300';
                    $data['dummy']['height'] = isset($manage_ad['dummy']['height']) ? sanitize_text_field($manage_ad['dummy']['height']) : '300';
        
                    // Update the post meta for ad type, URL, width, and height.
                    update_post_meta($post_id, '_manage_add_dummy', $data); 

                }
                elseif($type === 'image'){
                  
                    if (isset($manage_ad['image']['image_id']) && $manage_ad['image']['image_id'] !== '' && $manage_ad['image']['image_id'] !== '0') {
                        $data['image']['image_id'] = sanitize_text_field($manage_ad['image']['image_id']);
                    }

                    $data['image']['url'] = isset($manage_ad['image']['url']) ? sanitize_text_field($manage_ad['image']['url']) : '';
                    $data['image']['width'] = isset($manage_ad['image']['width']) ? sanitize_text_field($manage_ad['image']['width']) : '300';
                    $data['image']['height'] = isset($manage_ad['image']['height']) ? sanitize_text_field($manage_ad['image']['height']) : '300';                    
                    
                    // Update the custom post meta with URL, id ,  width, and height.
                    update_post_meta($post_id, '_manage_add_image', $data); 

                    
                }
                elseif ($type === 'group') {   
                    
                    // Prepare the group data as an array to store in post meta.
                    $data = array();
                    if (isset($manage_ad['group']['group_id'])) {
                        $data['group']['group_id'] = intval($manage_ad['group']['group_id']); 
                    }

                    // Sanitize width and height fields.
                    $data['group']['width'] = isset($manage_ad['group']['width']) ? intval($manage_ad['group']['width']) : 300;
                    $data['group']['height'] = isset($manage_ad['group']['height']) ? intval($manage_ad['group']['height']) : 300;
                    $data['group']['reverse_space'] = isset($manage_ad['group']['reverse_space']) ? $manage_ad['group']['reverse_space'] : '';

                    // Update the post meta for ad type group_id,  width, and height.                  
                    update_post_meta($post_id, '_manage_add_group', $data);                   
                }           
            }
            
        }
    }    
}

// Instantiate the class
new update_ads_type_parameter(); 
