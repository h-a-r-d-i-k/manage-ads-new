<?php

class Manage_Ads_Plain {
    public function get_parameters() {
        return '<p>' . __('Parameters for Plain Text and Code', 'manage-ads') . '</p>';
    }
}
