<?php

class Manage_Ads_Dummy {
       
    /**
     * 
     *
     * @param int .
     */
    public function __construct() {
    }  

    /**
     * Return the HTML parameters for the dummy ad.
     *
     * @return string HTML content.
     */
    public function get_parameters($add_id) {
        // Retrieve the meta value or use home URL as fallback       
        $img_src = MNG_DIR_URl . 'admin/images/dummy.jpg';
        $data = get_post_meta($add_id, '_manage_add_dummy', true);

        $url = isset($data['dummy']['url']) ? $data['dummy']['url'] : site_url();
        $width = isset($data['dummy']['width']) ? intval($data['dummy']['width']) : 300;
        $height = isset($data['dummy']['height']) ? intval($data['dummy']['height']) : 300;
              
    
        // Return the HTML block with proper escaping
        return sprintf(
            '<div id="manage-ads-ad-parameters" class="manage-option-list">
                <span class="label">%1$s</span>
                <div>
                    <input type="text" name="manage_ad[dummy][url]" id="manage-url" class="manage-ad-url" value="%2$s">
                </div>
                <hr>
                <img src="%3$s" width="%4$s" height="%5$s">
                <div>
                  <input type="number" name="manage_ad[dummy][width]" value="%4$s">
                  <input type="number" name="manage_ad[dummy][height]" value="%5$s">
                </div>
            </div>',
            // Parameters for placeholders
            esc_html__('URL', 'manage-ads'),  // %1$s: Label for URL
            $url,  // %2$s: Value for the URL input field
            $img_src,  // %3$s: Source for the image
            $width,  // %4$s: Width value for the image and width input field
            $height  // %5$s: Height value for the image and height input field
        );
    }
    
}

// Instantiate the class
new Manage_Ads_Dummy(); 
