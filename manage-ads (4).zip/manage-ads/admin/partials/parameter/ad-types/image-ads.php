<?php
class Manage_Ads_Image {
   
    /**
     * 
     *
     * @param int.
     */
    public function __construct() {
    }

    /**
     * Return the HTML parameters for the Image ad.
     *
     * @return string HTML content.
    */
    public function get_parameters($add_id) {

        $data = get_post_meta($add_id, '_manage_add_image', true);
        $image_id = isset($data['image']['image_id']) ? $data['image']['image_id'] : '0';
        $url = isset($data['image']['url']) ? $data['image']['url'] : site_url();
        $width = isset($data['image']['width']) ? intval($data['image']['width']) : 300;
        $height = isset($data['image']['height']) ? intval($data['image']['height']) : 300;    
        
    
        // Fetch image URL if image_id exists
        $image_preview = ''; 
        if ($image_id && $image_id != '0') {
            $attachment = wp_get_attachment_image_src($image_id, 'full'); 
            if ($attachment) {
                $image_preview = sprintf(
                    '<img src="%1$s" width="%2$s" height="%3$s" />',
                    esc_url($attachment[0]), // %1$s: Image URL
                    esc_attr($width), // %2$s: Width
                    esc_attr($height) // %3$s: Height
                );
            }
        }
    
        // Build the HTML output using sprintf
        $html = sprintf(
            '<div id="manage-ads-ad-parameters" class="manage-option-list">
                <span class="label">
                    <button class="manage_image_upload button manage-button-secondary" type="button" data-uploader-title="%1$s" data-uploader-button-text="%2$s">%3$s</button>
                </span>
                <div>
                    <input type="hidden" name="manage_ad[image][image_id]" value="%4$s" id="manage-image-id"> <!-- %4$s: Image ID hidden input -->
                    <div id="manage-image-preview">%5$s</div> <!-- %5$s: Image preview -->
                    <a id="manage-image-edit-link" class="hidden" href="#"><span class="dashicons dashicons-edit"></span></a>
                </div>
                <hr>
                <label for="manage-url" class="label">%6$s</label> <!-- %6$s: URL label -->
                <div>
                    <input type="url" name="manage_ad[image][url]" id="manage-url" class="manage-ad-url" value="%7$s" placeholder="%8$s">
                    <p class="description">%9$s</p> <!-- %9$s: URL description -->
                </div>
                <hr>
                <span class="label">%10$s</span> <!-- %10$s: Size label -->
                <div id="manage-ads-ad-parameters-size">
                    <label>%11$s<input type="number" value="%12$s" name="manage_ad[image][width]">px</label> <!-- %11$s: Width label, %12$s: Width value -->
                    <label>%13$s<input type="number" value="%14$s" name="manage_ad[image][height]">px</label> <!-- %13$s: Height label, %14$s: Height value -->
                    <label style="display:none;"><input type="checkbox" id="manage-wrapper-add-sizes" name="manage_ad[image][output][add_wrapper_sizes]" value="true" disabled="">%15$s</label> <!-- %15$s: Reserve space checkbox label -->
                </div>
                <hr>
            </div>',
            esc_attr__('Insert File', 'manage-ads'), // %1$s: Button title for uploading image
            esc_attr__('Insert', 'manage-ads'), // %2$s: Button text for uploading image
            esc_html__('Select Image', 'manage-ads'), // %3$s: Button label
            esc_attr($image_id), // %4$s: Image ID value
            $image_preview, // %5$s: Image preview HTML
            esc_html__('URL', 'manage-ads'), // %6$s: URL field label
            esc_url($url), // %7$s: URL field value
            esc_attr__('https://www.example.com/', 'manage-ads'), // %8$s: URL placeholder
            esc_html__('Link to target site including http(s)', 'manage-ads'), // %9$s: URL description
            esc_html__('Size', 'manage-ads'), // %10$s: Size section label
            esc_html__('Width', 'manage-ads'), // %11$s: Width label
            esc_attr($width), // %12$s: Width value
            esc_html__('Height', 'manage-ads'), // %13$s: Height label
            esc_attr($height), // %14$s: Height value
            esc_html__('Reserve this space', 'manage-ads') // %15$s: Reserve space checkbox label
        );
    
        return $html; 
    }

}

// Instantiate the class
new Manage_Ads_Image();
