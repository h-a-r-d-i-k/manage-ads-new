<?php

class Manage_Ads_Parameter {

    public function __construct() {
        add_action('add_meta_boxes', [$this, 'custom_manage_ads_meta_boxes']);
        add_action('add_meta_boxes', [$this, 'custom_manage_ads_parameter_boxes']);
        add_action('admin_enqueue_scripts', [$this, 'manage_ads_admin_scripts']);
        add_action('wp_ajax_manage_ads_update_parameters', [$this, 'manage_ads_update_parameters']);

       
        add_action('admin_enqueue_scripts', [$this,'my_plugin_enqueue_admin_scripts']);
         
        add_action('init', [$this, 'load_manage_ads_admin_files']);
    }
   
    /**
     * Load ad type files.
    */
    public function load_manage_ads_admin_files() {
        $files_to_include = array(
            'update-ads-type-parameter.php',
            'dummy-ads.php',           
            'group-ads.php',
            'image-ads.php'          
        );
     
        
        foreach ($files_to_include as $file) {
            $file_path = plugin_dir_path(__FILE__) . 'ad-types/' . $file;
           // echo $file_path;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }
    }

    public function custom_manage_ads_meta_boxes() {
        add_meta_box(
            'ad_main_box',
            __('Ad Type', 'manage-ads'),
            [$this, 'manage_ads_details_html'],
            'manage_ads',
            'normal',
            'high'
        );
    }

    public function custom_manage_ads_parameter_boxes() {
        add_meta_box(
            'ad-parameters-box',
            __('Ad Parameters', 'manage-ads'),
            [$this, 'custom_manage_ads_meta_box_callback'],
            'manage_ads',
            'normal',
            'default'
        );
    }

    public function manage_ads_details_html($post) {
        ?>
        <div class="inside">
            <ul id="ad-main-box-notices" class="MNG-metabox-notices"></ul>
            <ul id="manage-ad-type">
                <li class="manage-ads-type-list-plain">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-plain" value="plain" checked="checked">
                    <label for="manage-ad-type-plain"><?php _e('Plain Text and Code', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Any ad network, Amazon, customized AdSense codes, shortcodes, and code like JavaScript, HTML or PHP.', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-dummy">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-dummy" value="dummy">
                    <label for="manage-ad-type-dummy"><?php _e('Dummy', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Uses a simple placeholder ad for quick testing.', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-content">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-content" value="content">
                    <label for="manage-ad-type-content"><?php _e('Rich Content', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('The full content editor from WordPress with all features like shortcodes, image upload or styling, but also simple text/html mode for scripts and code.', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-image">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-image" value="image">
                    <label for="manage-ad-type-image"><?php _e('Image Ad', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Ads in various image formats.', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-group">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-group" value="group">
                    <label for="manage-ad-type-group"><?php _e('Ad Group', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Choose an existing ad group. Use this type when you want to assign the same display and visitor conditions to all ads in that group.', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-adsense">
                    <input type="radio" name="manage_ad[type]" id="manage-ad-type-adsense" value="adsense">
                    <label for="manage-ad-type-adsense"><?php _e('AdSense ad', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Use ads from your Google AdSense account', 'manage-ads'); ?></span></span>
                </li>
                <li class="manage-ads-type-list-gam">
                    <input type="radio" disabled="">
                    <label><?php _e('Google Ad Manager', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Load ad units directly from your Google Ad Manager account.', 'manage-ads'); ?></span></span>
                    <a href="<?php echo MANAGE_ADS_SITE_URL; ?>" target="_blank"><?php _e('Manual', 'manage-ads'); ?></a>
                </li>
                <li class="manage-ads-type-list-amp">
                    <input type="radio" disabled="">
                    <label><?php _e('AMP', 'manage-ads'); ?></label>
                    <span class="MNG-help"><span class="MNG-tooltip"><?php _e('Ads that are visible on Accelerated Mobile Pages.', 'manage-ads'); ?></span></span>
                    <a href="<?php echo MANAGE_ADS_SITE_URL; ?>" target="_blank"><?php _e('Manual', 'manage-ads'); ?></a>
                </li>
            </ul>
            <script>              
                jQuery(document).on('change', '#manage-ad-type input', function () {
                    MNG_update_ad_type_headline();
                });

                // dynamically move ad type to the meta box title
                var MNG_main_metabox_title = jQuery('#ad_main_box h2').text();
                function MNG_update_ad_type_headline(){
                    var MNG_selected_type = jQuery('#manage-ad-type input:checked + label').text();
                    var MNG_selected_id = jQuery('#manage-ad-type input:checked').attr('id');
                    jQuery('#ad_main_box h2').html(MNG_main_metabox_title + ': ' + MNG_selected_type);
                }
                MNG_update_ad_type_headline();
            </script>
        </div>
        <?php
    }

    public function custom_manage_ads_meta_box_callback($post) {
        ?>
        <div class="inside">
            <p><?php _e('Select an ad type to see parameters.', 'manage-ads'); ?></p>
        </div>
        <?php
    }

    public function manage_ads_admin_scripts() {
        wp_enqueue_script(
            'manage-ads-parameter',
            MNG_DIR_URl . 'admin/js/manage-ads-parameter.js',
            array('jquery'),
            null,
            true
        );
        wp_localize_script(
            'manage-ads-parameter',
            'manageAdsAjax',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('manage_ads_nonce')
            )
        );
    }

    public function manage_ads_update_parameters() {
        check_ajax_referer('manage_ads_nonce', 'security');
        
        $ad_type = sanitize_text_field($_POST['ad_type']);
        $post_id = intval($_POST['post_id']);
    
        $response = '';
        $class_file = plugin_dir_path(__FILE__) . 'ad-types/' . $ad_type . '-ads.php';
    
        if (file_exists($class_file)) {
            require_once $class_file;
            
            $class_name = 'Manage_Ads_' . ucfirst($ad_type);
            
            if (class_exists($class_name)) {
                // Pass post_id to the class constructor
                $ad_class = new $class_name($post_id);
                $response .= $ad_class->get_parameters($post_id);
            } else {
                $response .= '<p>' . __('Class not found for', 'manage-ads') . ' ' . $ad_type . '</p>';
            }
        } else {
            $response .= '<p>' . __('Class file not found for', 'manage-ads') . ' ' . $ad_type . '</p>';
        }
    
        wp_send_json_success(array('html' => $response));
    }      
    public function my_plugin_enqueue_admin_scripts() {
        wp_enqueue_media();
        wp_enqueue_script('my-plugin-admin-script',  MNG_DIR_URl . 'admin/js/manage-ads-image-content.js', array('jquery'), '1.0', true);
    }
}

new Manage_Ads_Parameter();
