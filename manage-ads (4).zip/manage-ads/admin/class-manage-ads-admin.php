<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://https://dazzlebirds.com/
 * @since      1.0.0
 *
 * @package    Manage_Ads
 * @subpackage Manage_Ads/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Manage_Ads
 * @subpackage Manage_Ads/admin
 * @author     Hardik Mehta <methahardik24@gmail.com>
 */


class Manage_Ads_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	// public function __construct( $plugin_name, $version ) {

	// 	$this->plugin_name = $plugin_name;
	// 	$this->version = $version;

	// 	add_action( 'admin_menu', array( $this, 'manage_ads_admin_menu' ) );
    //     add_action('init', array($this, 'create_ads_custom_post_type'));

	// }
    
	public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        add_action('admin_menu', array($this, 'manage_ads_admin_menu'));
        add_action('init', array($this, 'create_ads_custom_post_type'));

		add_action('init', array($this, 'register_group_taxonomy'));
		add_action('init', array($this, 'register_placement_taxonomy'));

		add_action('admin_post_bulk_delete_manage_ads_groups', array($this , 'bulk_delete_manage_ads_groups'));
		add_action('admin_post_save_ad_group', array($this ,'save_manage_ad_group'));

		add_action('admin_post_save_ad_placement', array($this ,'save_manage_ad_placement'));
		add_action('admin_post_bulk_delete_manage_ads_placement', array($this , 'bulk_delete_manage_ads_placement'));

        // Initialize header class and hooks
        $header = new Manage_Ads_Header();
        $header->hooks();

		// Include and initialize Manage_Ads_Parameter class
        require_once plugin_dir_path(__FILE__) . 'partials/parameter/manage-ads-parameter.php';
        new Manage_Ads_Parameter();
    }


	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Manage_Ads_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Manage_Ads_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/manage-ads-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Manage_Ads_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Manage_Ads_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/manage-ads-admin.js', array( 'jquery' ), $this->version, false );

	}

    /**------Add Menu and submenu in Manage Ads------- */
	
    public function manage_ads_admin_menu() {

        // Add top level menu page
        add_menu_page(
            'Manage Ads',
            'Manage Ads',
            'manage_options',
            'manage-ads',
            array($this, 'manage_ads_dashboard_page'),
            'dashicons-admin-manage-ads',
            6
        );

        // Add submenu page for "Dashboard" (same page as top level menu)
        add_submenu_page(
            'manage-ads',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'manage-ads',
            array($this, 'manage_ads_dashboard_page')
        );

		// Register 'manage_ads' post type
		add_submenu_page(
			'manage-ads',
			'Ads',
			'Ads',
			'manage_options',
			'edit.php?post_type=manage_ads'
		);
		
         // Add submenu page for "Ads Groups"
		 add_submenu_page(
            'manage-ads',
            'Manage Ads Groups',
            'Ads Groups',
            'manage_options',
            'manage-ads-groups',
            array($this, 'manage_ads_groups_page')
        );

        add_submenu_page(
            'manage-ads',
            'Ads Placements',
            'Ads Placements',
            'manage_options',
            'manage-ads-placements',
            array($this, 'manage_ads_placements_page')
        );

        add_submenu_page(
            'manage-ads',
            'Settings',
            'Settings',
            'manage_options',
            'manage-ads-settings',
            array($this, 'manage_ads_settings_page')
        );

    }
     

	
    public function manage_ads_dashboard_page() {
		require_once MANAGE_ADS_PLUGIN_PATH. 'admin/partials/manage-ads-dashboard.php';
	 }
 
	 public function manage_ads_groups_page() {		
	    require_once MANAGE_ADS_PLUGIN_PATH. 'admin/partials/manage-ads-groups-page.php';
	 }
 
	 public function manage_ads_placements_page() {
	    require_once MANAGE_ADS_PLUGIN_PATH. 'admin/partials/manage-ads-placements-page.php';
	 }
 
	 public function manage_ads_settings_page() {
		require_once MANAGE_ADS_PLUGIN_PATH. 'admin/partials/manage-ads-settings-page.php';
	 }

    public function create_ads_custom_post_type() {
		$labels = array(
			'name' => 'Ads',
			'singular_name' => 'Ad',
			'menu_name' => 'Ads',
			'name_admin_bar' => 'Ad',
			'add_new' => 'Add New Ad',
			'add_new_item' => 'Add New Ad',
			'new_item' => 'New Ad',
			'edit_item' => 'Edit Ad',
			'view_item' => 'View Ad',
			'search_items' => 'Search Ads',
			'not_found' => 'No ads found.',
			'not_found_in_trash' => 'No ads found in Trash.'
		);
	
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => false, // Do not show in any menu
			'query_var' => true,
			'rewrite' => array('slug' => 'manage_ads'),
			'capability_type' => 'post',
			'has_archive' => true,
			'hierarchical' => false,
			'menu_position' => null,
			'supports' => array('title')
		);
	
		register_post_type('manage_ads', $args);
	}
	public function register_group_taxonomy() {
        $labels = array(
            'name' => 'Ad Groups',
            'singular_name' => 'Ad Group',
            'search_items' => 'Search Ad Groups',
            'all_items' => 'All Ad Groups',
            'parent_item' => 'Parent Ad Groups',
            'parent_item_colon' => 'Parent Ad Groups:',
            'edit_item' => 'Edit Ad Group',
            'update_item' => 'Update Ad Group',
            'add_new_item' => 'Add New Ad Group',
            'new_item_name' => 'New Ad Group Name',
            'menu_name' => 'Ad Groups',
            'not_found' => 'No Ad Groups found'
        );

        $args = array(
            'public' => false,
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_in_nav_menus' => false,
            'show_in_menu' => false,
            'show_tagcloud' => false,
            'show_admin_column' => true,
            'query_var' => false,
            'rewrite' => false,
            'capabilities' => array(
                'manage_terms' => 'manage_options',
                'edit_terms' => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            )
        );

        register_taxonomy('manage_ads_group', 'manage_ads', $args);
    }
    public function register_placement_taxonomy() {
        $labels = array(
            'name' => 'Ad Placements',
            'singular_name' => 'Ad Placement',
            'search_items' => 'Search Ad Placements',
            'all_items' => 'All Ad Placements',
            'parent_item' => 'Parent Ad Placements',
            'parent_item_colon' => 'Parent Ad Placements:',
            'edit_item' => 'Edit Ad Placement',
            'update_item' => 'Update Ad Placement',
            'add_new_item' => 'Add New Ad Placement',
            'new_item_name' => 'New Ad Placement Name',
            'menu_name' => 'Ad Placements',
            'not_found' => 'No Ad Placements found'
        );

        $args = array(
            'public' => false,
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_in_nav_menus' => false,
            'show_in_menu' => false,
            'show_tagcloud' => false,
            'show_admin_column' => true,
            'query_var' => false,
            'rewrite' => false,
            'capabilities' => array(
                'manage_terms' => 'manage_options',
                'edit_terms' => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            )
        );

        register_taxonomy('manage_ads_placement', 'manage_ads', $args);
    }


	public function bulk_delete_manage_ads_groups() {
		// Check nonce for security
		if (!isset($_POST['_wpnonce_bulk_action']) || !wp_verify_nonce($_POST['_wpnonce_bulk_action'], 'bulk_action_nonce')) {
			wp_die(__('You are not authorized to perform this action.', 'manage-ads'));
		}

		if (isset($_POST['bulk-action']) && $_POST['bulk-action'] === 'delete' && isset($_POST['bulk-delete'])) {
			$term_ids = array_map('intval', $_POST['bulk-delete']);
			foreach ($term_ids as $term_id) {
				wp_delete_term($term_id, 'manage_ads_group');
			}
		}

		// Redirect back to the ad groups page
		wp_redirect(admin_url('admin.php?page=manage-ads-groups'));
		exit;
	}

   
	public function bulk_delete_manage_ads_placement() {
		// Check nonce for security
		if (!isset($_POST['_wpnonce_bulk_action']) || !wp_verify_nonce($_POST['_wpnonce_bulk_action'], 'bulk_action_nonce')) {
			wp_die(__('You are not authorized to perform this action.', 'manage-ads'));
		}

		if (isset($_POST['bulk-action']) && $_POST['bulk-action'] === 'delete' && isset($_POST['bulk-delete'])) {
			$term_ids = array_map('intval', $_POST['bulk-delete']);
			foreach ($term_ids as $term_id) {
				wp_delete_term($term_id, 'manage_ads_placement');
			}
		}

		// Redirect back to the ad placement page
		wp_redirect(admin_url('admin.php?page=manage-ads-placements'));
		exit;
	}

	public function save_manage_ad_group() {
		// Check nonce for security
		if (!isset($_POST['ad_group_nonce']) || !wp_verify_nonce($_POST['ad_group_nonce'], 'save_ad_group')) {
			wp_die(__('You are not authorized to perform this action.', 'manage-ads'));
		}
	
		// Get the term ID if it's an edit operation
		$term_id = isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
	
		// Prepare term data
		$name = sanitize_text_field($_POST['name']);
		$manage_group_type = isset($_POST['manage-group-type']) ? sanitize_text_field($_POST['manage-group-type']) : '';
		$manage_group_visible_ads_count = isset($_POST['manage_group_visible_ads_count']) ? sanitize_text_field($_POST['manage_group_visible_ads_count']) : '1';
	
		// Validate manage group type
		if (!in_array($manage_group_type, array('random', 'ordered'))) {
			wp_die(__('Invalid manage group type.', 'manage-ads'));
		}
	
		$term_data = array(
			'name' => $name,
			'slug' => sanitize_title($name),
		);
	
		if ($term_id) {
			// Edit existing term
			$result = wp_update_term($term_id, 'manage_ads_group', $term_data);
			if (!is_wp_error($result)) {
				// Update term metadata
				update_term_meta($term_id, 'manage_group_type', $manage_group_type);
				update_term_meta($term_id, 'manage_group_visible_ads_count', $manage_group_visible_ads_count);
		
				// Get selected post IDs
				$selected_manage_ads_posts = isset($_POST['selected_manage_ads_posts']) ? array_map('intval', $_POST['selected_manage_ads_posts']) : array();
				update_term_meta($term_id, 'selected_manage_ads_posts', $selected_manage_ads_posts);
		
				// Assign term to selected posts and remove from unselected posts
				$args = array(
					'post_type' => 'manage_ads',
					'numberposts' => -1,
					'tax_query' => array(
						array(
							'taxonomy' => 'manage_ads_group',
							'field' => 'term_id',
							'terms' => $term_id,
						),
					),
					'fields' => 'ids',
				);
				$current_posts = get_posts($args);
		
				// Remove term from posts that are not in the selected posts
				$posts_to_remove_term = array_diff($current_posts, $selected_manage_ads_posts);
				foreach ($posts_to_remove_term as $post_id) {
					wp_remove_object_terms($post_id, $term_id, 'manage_ads_group');
				}
		
				// Assign term to selected posts
				foreach ($selected_manage_ads_posts as $post_id) {
					wp_set_object_terms($post_id, $term_id, 'manage_ads_group', true);
				}
			}
		} else {
			// Add new term
			$result = wp_insert_term($name, 'manage_ads_group', $term_data);
			if (!is_wp_error($result)) {
				$term_id = $result['term_id'];
		
				// Update term metadata
				update_term_meta($term_id, 'manage_group_type', $manage_group_type);
				update_term_meta($term_id, 'manage_group_visible_ads_count', $manage_group_visible_ads_count);
		
				// Get selected post IDs
				$selected_manage_ads_posts = isset($_POST['selected_manage_ads_posts']) ? array_map('intval', $_POST['selected_manage_ads_posts']) : array();
				update_term_meta($term_id, 'selected_manage_ads_posts', $selected_manage_ads_posts);
		
				// Assign term to selected posts
				foreach ($selected_manage_ads_posts as $post_id) {
					wp_set_object_terms($post_id, $term_id, 'manage_ads_group', true);
				}
			}
		}
	
		// Redirect back to the ad groups page
		wp_redirect(admin_url('admin.php?page=manage-ads-groups'));
		exit;
	}

	public function save_manage_ad_placement() {
		// Check nonce for security
		if (!isset($_POST['ad_placement_nonce']) || !wp_verify_nonce($_POST['ad_placement_nonce'], 'save_ad_placement')) {
			wp_die(__('You are not authorized to perform this action.', 'manage-ads'));
		}
	
		// Get the term ID if it's an edit operation
		$term_id = isset($_POST['term_id']) ? intval($_POST['term_id']) : 0;
	
		// Prepare term data
		$name = sanitize_text_field($_POST['name']);
		$manage_placement_type = isset($_POST['manage-placement-type']) ? sanitize_text_field($_POST['manage-placement-type']) : '';
		
		// Validate manage placement type
		if (!in_array($manage_placement_type, array('manual', 'footer-code', 'header-code'))) {
			wp_die(__('Invalid manage placement type.', 'manage-ads'));
		}
	
		$term_data = array(
			'name' => $name,
			'slug' => sanitize_title($name),
		);
	
		if ($term_id) {
			// Edit existing term
			$result = wp_update_term($term_id, 'manage_ads_placement', $term_data);
			if (!is_wp_error($result)) {
				update_term_meta($term_id, 'manage_placement_type', $manage_placement_type);
				update_term_meta($term_id, 'selected_placement', isset($_POST['selected_placement']) ?  $_POST['selected_placement'] : '');
			}
		} else {
			// Add new term
			$result = wp_insert_term($name, 'manage_ads_placement', $term_data);
			if (!is_wp_error($result)) {
				$term_id = $result['term_id'];
				update_term_meta($term_id, 'manage_placement_type', $manage_placement_type);
				update_term_meta($term_id, 'selected_placement', isset($_POST['selected_placement']) ?  $_POST['selected_placement'] : '');
			}
		}
	
		// Redirect back to the ad placements page
		wp_redirect(admin_url('admin.php?page=manage-ads-placements'));
		exit;
	}
	
}
