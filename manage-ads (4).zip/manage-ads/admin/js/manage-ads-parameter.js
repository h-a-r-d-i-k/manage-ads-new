jQuery(document).ready(function ($) {
    $('#manage-ad-type input').on('change', function () {
        var selectedType = $('#manage-ad-type input:checked').val();
        var postId = $('#post_ID').val(); 
        $.ajax({
            url: manageAdsAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'manage_ads_update_parameters',
                security: manageAdsAjax.nonce,
                ad_type: selectedType,
                post_id: postId
            },
            success: function (response) {
                if (response.success) {
                    $('#ad-parameters-box .inside').html(response.data.html);
                }
            }
        });
    });
});

