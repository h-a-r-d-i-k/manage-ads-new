jQuery(document).ready(function($) {
    var mediaUploader;

    // Function to initialize the media uploader
    function initializeMediaUploader() {
        $('.manage_image_upload').off('click').on('click', function(e) {
            e.preventDefault();

            // If the media uploader already exists, open it
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            // Create a new media uploader
            mediaUploader = wp.media({
                title: $(this).data('uploader-title'),
                button: {
                    text: $(this).data('uploader-button-text')
                },
                multiple: false
            });

            // When a file is selected, run a callback
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#manage-image-id').val(attachment.id);
                $('#manage-image-preview').html('<img src="' + attachment.url + '" style="width:300px; height:300px;" />');
                $('#manage-image-edit-link').attr('href', attachment.editLink).removeClass('hidden');
            });

            // Open the media uploader
            mediaUploader.open();
        });
    }

    // Initialize media uploader on page load
    initializeMediaUploader();

    // Re-initialize media uploader after dynamic HTML is added
    $(document).ajaxComplete(function() {
        initializeMediaUploader();
    });
});
