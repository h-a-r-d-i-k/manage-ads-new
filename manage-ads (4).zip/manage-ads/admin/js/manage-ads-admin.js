(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

})( jQuery );

jQuery(document).ready(function() {
    jQuery('.manage_ads_form input#submit').on('click', function(event) {
        let formValid = true;
        const errorClass = '.manage_ads_error'; 

        // Function to validate input fields
        function validateField(selector) {
            const $field = jQuery(selector);
            const $message = $field.next(errorClass);

            if ($field.length > 0 && $field.val().trim() === '') {
                $message.show();
                formValid = false;
            } else {
                $message.hide();
            }
        }

        // Function to validate radio buttons
        function validateRadioGroup(name) {
            const $group = jQuery(`input[name="${name}"]`);
            const $message = $group.closest('.manage-form-types').next(errorClass);

            if ($group.length > 0 && $group.filter(':checked').length === 0) {
                $message.show();
                formValid = false;
            } else {
                $message.hide();
            }
        }

        // Check if fields in form
        if (jQuery('.manage_ads_form input[name="name"]').length > 0) {
            validateField('#name');
        }

        if (jQuery('.manage_ads_form input[name="manage-group-type"]').length > 0) {
            validateRadioGroup('manage-group-type');
        }

        if (jQuery('.manage_ads_form input[name="manage-placement-type"]').length > 0) {
            validateRadioGroup('manage-placement-type');
        }

        // Prevent form submission if any validation fails
        if (!formValid) {
            event.preventDefault();
        }
    });
});

